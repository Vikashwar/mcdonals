function myfunction1(){
    event.preventDefault()
    }   
    
    function myfunction2(){
        var h1=document.getElementById("script_h1").textContent="Pizza McPuff®";
        
        var h2=document.getElementById("script_h2").textContent="Something different. Something delicious"
        var p=document.getElementById("script_p").textContent="A blend of assorted vegetables (carrot, beans,capsicum, onion & green peas); mozzarella cheese mixed with tomato sauce; and exotic spices stuffed in rectangle shaped savoury dough. Quick frozen."
        var h3=document.getElementById("script_h3").textContent="Serving Size:87 gm";
        var h22=document.getElementById("script_h22").textContent="Allergen Warning! Contains:"
        var pp=document.getElementById("script_pp").textContent="Gluten, Milk and/or Milk products, Soybean derivative";
            
        var box=document.getElementById("box_img22")
        box.src="https://mcdindia.com/wp-content/uploads/2020/02/3.1-pizza-mcpuff.png";
        
        event.preventDefault();
        }
        function myfunction3(){
            var h1=document.getElementById("script_h1").textContent="McFlurry (Oreo)®";
            
            var h2=document.getElementById("script_h2").textContent="Burgers aren't the only things we're good at."
            var p=document.getElementById("script_p").textContent="Milk-based frozen dessert with oreo cookies"
            var h3=document.getElementById("script_h3").textContent="Serving Size: 87 gm | 147 gm";
            var h22=document.getElementById("script_h22").textContent="Allergen Warning! Contains:"
            var pp=document.getElementById("script_pp").textContent="Gluten, Milk and/or Milk products";
            
            var box=document.getElementById("box_img22")
            box.src="https://mcdindia.com/wp-content/uploads/2020/02/4.1-mcflurry-oreo.png";
            
            event.preventDefault();
            }
        
            function myfunction4(){
                var h1=document.getElementById("script_h1").textContent="Black Coffee®";
                
                var h2=document.getElementById("script_h2").textContent="Perfectly brewed for any time of the day."
                var p=document.getElementById("script_p").textContent="A blend of assorted vegetables (carrot, beans,capsicum, onion & green peas); mozzarella cheese mixed with tomato sauce; and exotic spices stuffed in rectangle shaped savoury dough. Quick frozen."
                var h3=document.getElementById("script_h3").textContent="Serving Size:200ml";
                var h22=document.getElementById("script_h22").textContent="Note:"
                var pp=document.getElementById("script_pp").textContent="Milk tubs and sugar sachets available separately";
                
                var box=document.getElementById("box_img22")
                box.src="https://mcdindia.com/wp-content/uploads/2020/03/5.1-coffee-large-1.png";
                
                event.preventDefault();
                }
        function slid1(){
            var x=document.getElementById("Script_head1").textContent="Now Order"
            var y=document.getElementById("Script_head2").textContent="Wholesome Whole Wheat"
         var z=document.getElementById("right").style.backgroundImage="url('https://scontent.cdninstagram.com/v/t51.2885-15/273728127_522494585799561_5642259969929804340_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=8ae9d6&_nc_ohc=-t88ZIF-xGwAX9TBOEn&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AT9v4Y1IXAgENvLRKtqTbcDceuDnsqiPWjqZxapux4zodw&oe=6221CD3D')"
        
            event.preventDefault()
        }
        function slid2(){
            var x=document.getElementById("Script_head1").textContent="Now Order"
            var y=document.getElementById("Script_head2").textContent="Wholesome Whole Wheat"
    
        var z=document.getElementById("right").style.backgroundImage="url('https://mcdindia.com/wp-content/uploads/2020/07/img1-2.jpg')"
            event.preventDefault()
        }
        function change1(){
            var x=document.getElementById("scri_img11")
            x.src="https://mcdindia.com/wp-content/uploads/2022/01/masala-dosa-burger-1.png"
            var y=document.getElementById("scri_imgh1").textContent="Grilled Butter"
            var z=document.getElementById("scri_img111")
            z.src="https://mcdindia.com/wp-content/uploads/2022/01/paneer-1.png"
            var a=document.getElementById("scri_imgh11").textContent="Chicken pups"
            var b=document.getElementById("scri_img1111")
            b.src="https://mcdindia.com/wp-content/uploads/2020/02/3.2-6pcs-chicken-nuggets.png"
            var c=document.getElementById("scri_imgh111").textContent="egg pups"
            var box=document.getElementById("box_img22")
        box.src="https://mcdindia.com/wp-content/uploads/2020/02/3.2-6pcs-chicken-nuggets.png";
    
        }
    
        function change2(){
            var x=document.getElementById("scri_img11")
            x.src="https://mcdindia.com/wp-content/uploads/2022/01/masala-dosa-burger-1.png"
            var y=document.getElementById("scri_imgh1").textContent="Grilled Butter Chicken Burger"
            var z=document.getElementById("scri_img111")
            z.src="https://mcdindia.com/wp-content/uploads/2022/01/paneer-1.png"
            var a=document.getElementById("scri_imgh11").textContent="Dosa Masala Burger"
            var b=document.getElementById("scri_img1111")
            b.src="https://mcdindia.com/wp-content/uploads/2020/02/3.2-6pcs-chicken-nuggets.png"
            var c=document.getElementById("scri_imgh111").textContent="Veg Maharaja Mac"
            var box=document.getElementById("box_img22")
            box.src="https://mcdindia.com/wp-content/uploads/2022/01/paneer-1.png";
            var box=document.getElementById("box_img22")
            box.src="https://mcdindia.com/wp-content/uploads/2022/01/paneer-1.png";
    
        }
     